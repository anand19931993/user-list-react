import React, { Fragment } from 'react'
const Footer = () => {
return(
    <Fragment>
        <div className="bg-cust footer-cust mt-5">
        <p>Copyright © 2020</p>
        </div>
    </Fragment>
)
}

export default Footer